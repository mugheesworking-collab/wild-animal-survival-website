# Project history and transfer status

Prepared for transfer to AntiGravity on 30 October 2026.

## Owner's explicit decisions

- Official title: Wild Animal Survival Sim 3D.
- Studio brand: Gameyard, as explicitly clarified in chat.
- Android / Google Play CTAs only. No Apple App Store buttons.
- Preserve the reference homepage's section types and order, with wildlife content.
- Use the supplied forest-green and golden-yellow palette exactly.
- Use real game media where available; do not invent game features or screenshots.
- Continue and finish development in AntiGravity.

## Work completed on 20 October 2026

The brief and color image were studied. The Call of Duty: Mobile homepage and game's Google Play listing were read. A static HTML/CSS/JavaScript website was built, using eight publisher-provided store images and local fonts. Interactive tabs, animal panels, mobile menu, media expansion, image dialog and reduced-motion support were implemented.

Browser checks passed at 320, 390, 768, 1024 and 1440 pixel widths. These covered visible images, horizontal overflow, Play Store links, tabs, animal panels, gallery expansion and lightbox controls, Escape and mobile navigation. JavaScript syntax passed Node checks. Screenshots in this folder are saved views from that work; no current live-browser audit was performed solely for this handoff.

The site was privately deployed at https://wild-animal-survival-gameyard.team-ozforsolutions.chatgpt.site. Deployment succeeded on 20 October. Availability and current access have not been rechecked for this transfer.

## Material limitations / finalization work

- Owner has not yet approved the final design in this conversation. Treat the site as an implementation to refine, not a signed-off final release.
- Section coverage follows the reference as read on 20 October; exact present-day visual or animation parity has not been established.
- No real trailer, official logo file, collaboration announcement or official social URLs were supplied. The collaboration section uses an empty state; the gallery uses still images.
- Store screenshots include publisher UI and promotional material. They are not independently verified current-binary captures.
- The brief has ideas and development work that are not release confirmations. Family/den features and other speculative systems were not marketed as live.
- Verify any changed roster, map naming, current store update or public publisher details before revising factual claims.
- Gameyard branding and Hush Games publisher attribution are separated. Existing game policy/support links came from Google Play. Website-specific policies and final hosting/domain choices remain to be decided as needed.
- Historical checks do not constitute Lighthouse benchmarks, a screen-reader audit, game QA or a real-device certification.

## Transfer packaging

`dist/` is copied from the existing site without changing the website. The full original Markdown brief is included. The color guide is transcribed because the temporary PNG is no longer present. The new preview script and package.json provide a portable, dependency-free local launch command. Original Codex-specific Git/hosting metadata and credentials are excluded. Old files and the hosted preview are retained; no deletion or unpublishing was requested.

`MASTER-PROMPT.md` is a curated transfer of relevant conversation requirements, decisions and implementation context, not a verbatim chat transcript.
