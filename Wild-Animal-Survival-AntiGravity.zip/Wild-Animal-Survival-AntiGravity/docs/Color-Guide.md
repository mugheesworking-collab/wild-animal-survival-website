# Color guide — transcription of the supplied image

Original image heading: WILD ANIMAL SURVIVAL SIM 3D — Brand palette & usage | October 2026.

| Role | Color | Hex |
| --- | --- | --- |
| Primary | Forest Green | #19452F |
| Accent | Golden Yellow | #F2B400 |
| Main background | Deep Jungle | #101F18 |
| Alternate section | Dark Forest | #142B20 |
| Cards / hover | Elevated Green | #28573E |
| Body text | Sage Gray | #C5D2C9 |
| Headings | White | #FFFFFF |
| Borders | Muted Green | #3C5B49 |

Suggested visual distribution: 55% dark base, 25% forest green, 10% yellow accent, 10% text/neutral.

Usage rules from the guide:

- Page background: Deep Jungle #101F18. Use Forest Green in header, signature sections and overlays.
- CTA buttons, active links, underline accents and key labels: Golden Yellow #F2B400.
- Cards: Dark Forest #142B20 / Elevated Green #28573E; dividers: Muted Green #3C5B49.
- Headings: White #FFFFFF; secondary body text: Sage Gray #C5D2C9.
- Yellow buttons use dark text (#101F18); avoid long yellow paragraphs or yellow-on-white text.
- Let actual gameplay screenshots carry the color variation. Do not tint every image green.

Style reference in the image: callofduty.com/mobile.

The original PNG was supplied through a temporary clipboard path and is no longer available at that path. This transcription preserves its colors and usage rules; it is not a replacement logo or new visual asset.
